from setuptools import setup, find_packages

setup(
    name='logcat-color',
    version='0.10.0',
    description='Improved and colorful logcat output for Python 3',
    author='Sangsoo Kim',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'logcat-color=logcatcolor.main:main',
        ],
    },
    install_requires=[
        'colorama',
    ],
    python_requires='>=3.6',
    include_package_data=True,
    zip_safe=False,
)

#     author='sangsoo kim',