"""
logcat-color

Copyright 2012, Marshall Culpepper
Licensed under the Apache License, Version 2.0

Columns for displaying logcat log data
"""
from __future__ import unicode_literals
import colorama
import textwrap
from colorama import Fore, Back, Style
from io import StringIO
import fnmatch

colorama.init()

class Column(object):
    def __init__(self, layout):
        self.width = layout.config.get_column_width(self)

    def format(self, data):
        return self.FORMAT % data

class DateColumn(Column):
    NAME = "date"
    FORMAT = Fore.WHITE + Back.BLACK + Style.NORMAL + \
             "%s" + Style.RESET_ALL
    DEFAULT_WIDTH = 7

class TimeColumn(Column):
    NAME = "time"
    FORMAT = Fore.WHITE + Back.BLACK + Style.NORMAL + \
             "%s" + Style.RESET_ALL
    DEFAULT_WIDTH = 14

class PIDColumn(Column):
    NAME = "pid"
    DEFAULT_WIDTH = 8
    FORMAT = Fore.WHITE + Back.BLACK + Style.NORMAL + \
             "%s" + Style.RESET_ALL

    def format(self, pid):
        # center process info
        if self.width > 0:
            pid = pid.center(self.width)

        return Column.format(self, pid)

class TIDColumn(PIDColumn):
    NAME = "tid"

    def format(self, tid):
        # normalize thread IDs to be decimal
        if "0x" in tid:
            tid = str(int(tid, 16))

        return PIDColumn.format(self, tid)

class TagColumn(Column):
    NAME = "tag"
    DEFAULT_WIDTH = 20
    
    COLOR_STYLES = [
        style + color
        for style in (Style.BRIGHT, Style.NORMAL)
        for color in (
            Fore.RED, Fore.GREEN, Fore.YELLOW,
            Fore.BLUE, Fore.MAGENTA, Fore.CYAN, Fore.WHITE
        )
    ]
    COLOR_MAP = {}

    @classmethod
    def get_color(cls, tag):
        if tag in cls.COLOR_MAP:
            return cls.COLOR_MAP[tag]
        index = abs(hash(tag)) % len(cls.COLOR_STYLES)
        cls.COLOR_MAP[tag] = cls.COLOR_STYLES[index]
        # print("[logcat-color] Tag color: %d %s -> %d" % (index, tag, cls.COLOR_STYLES[index]))
        return cls.COLOR_MAP[tag]

    def __init__(self, layout):
        Column.__init__(self, layout)
        self.tag_colors = getattr(layout.profile, "tag_colors", {}) if layout and layout.profile else {}
        
    def match_tag(self, tag):
        tag = tag.strip() if tag else ""
        

        if tag in self.tag_colors:
            return self.tag_colors[tag]
        
        for pattern, color in self.tag_colors.items():
            if fnmatch.fnmatch(tag, pattern):
                return color
        
        return None

    def format(self, tag):
          
        if not tag:
            tag = ""

        color = self.match_tag(tag)
        
        if color is None:
            color = self.get_color(tag)
        
        # if not self.match_tag(tag):
        #     color = self.get_color(tag)
        # color = self.match_tag(tag) or self.tag_colors.get(tag)
        
        if self.width > 2 and len(tag) > self.width:
            tag = tag[:self.width-2] + ".."

        tag = tag.rjust(self.width)
        return color + tag + Style.RESET_ALL


class PriorityColumn(Column):
    NAME = "priority"
    DEFAULT_WIDTH = 3
    COLORS = {
        "V": Fore.WHITE + Back.BLACK,
        "D": Fore.BLACK + Back.BLUE,
        "I": Fore.BLACK + Back.GREEN,
        "W": Fore.BLACK + Back.YELLOW,
        "E": Fore.BLACK + Back.RED,
        "F": Fore.BLACK + Back.RED,
        "S": Fore.BLACK + Back.WHITE
    }

    def __init__(self, layout):
        Column.__init__(self, layout)
        self.formats = {}
        for priority in self.COLORS.keys():
            self.formats[priority] = self.COLORS[priority] + \
                priority.center(self.width) + Style.RESET_ALL

    def format(self, priority):
        return self.formats[priority]

class MessageColumn(Column):
    NAME = "message"
    DEFAULT_WIDTH = 0
    def __init__(self, layout):
        self.width = None
        self.left = layout.total_column_width
        if layout.config.get_wrap() and (not layout.profile or layout.profile.wrap):
            self.width = layout.width - self.left - 2
            self.left = self.left + 2

    def format(self, message):
        # Don't wrap when width is None
        if not self.width:
            return message

        indent = " " * self.left
        # 단어 단위로 줄바꿈
        wrapped_lines = textwrap.wrap(message, width=self.width)

        # 첫 줄은 그대로, 이후 줄에는 indent 붙여서 정렬 맞춤
        return ("\n" + indent).join(wrapped_lines)
